package com.biochem.easy

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF102A43)
private val Teal = Color(0xFF16A6A1)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { BiochemistryApp() }
    }
}

@Composable
fun BiochemistryApp() {
    var code by remember { mutableStateOf("") }
    var activated by remember { mutableStateOf(false) }
    var selected by remember { mutableIntStateOf(-1) }
    var submitted by remember { mutableStateOf(false) }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Navy,
            secondary = Teal,
            background = Color(0xFFF5F8FA)
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFFF5F8FA)) {
            Column(
                modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(24.dp))
                Text("BIOCHEMISTRY", color = Teal, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Text("Easy with Me", color = Navy, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                Text("By Dr. Ahmed Al-Kisher  •  Edition 2027", color = Color.DarkGray, fontSize = 12.sp)
                Spacer(Modifier.height(28.dp))
                Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(Modifier.padding(18.dp)) {
                        Text("Student Access", color = Navy, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text("Enter the subscription code provided by your teacher.")
                        OutlinedTextField(
                            value = code,
                            onValueChange = { code = it; activated = false },
                            label = { Text("Subscription code") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(Modifier.height(10.dp))
                        Button(
                            onClick = { activated = code.trim().isNotEmpty() },
                            enabled = code.trim().isNotEmpty(),
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = Teal)
                        ) { Text("Continue") }
                        if (activated) {
                            Text("Demo access enabled. Online code verification is not connected yet.", color = Navy)
                        }
                    }
                }
                Spacer(Modifier.height(18.dp))
                Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(Modifier.padding(18.dp)) {
                        Text("Sample Biochemistry Quiz", color = Navy, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(10.dp))
                        Text("Which molecule is the primary energy currency of the cell?", fontWeight = FontWeight.SemiBold)
                        listOf("ATP", "DNA", "Urea", "Cholesterol").forEachIndexed { index, answer ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(selected = selected == index, onClick = { selected = index; submitted = false })
                                Text(answer)
                            }
                        }
                        Button(
                            onClick = { submitted = true },
                            enabled = selected >= 0,
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Submit answer") }
                        if (submitted) {
                            Text(
                                if (selected == 0) "Correct! ATP transfers usable energy in cells."
                                else "Not quite. The correct answer is ATP.",
                                color = if (selected == 0) Color(0xFF16804A) else Color(0xFFB3261E),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
                Spacer(Modifier.height(22.dp))
                Text(
                    "Starter build • Sample quiz only • Connect Firebase before student launch",
                    color = Color.Gray,
                    fontSize = 11.sp
                )
            }
        }
    }
}
