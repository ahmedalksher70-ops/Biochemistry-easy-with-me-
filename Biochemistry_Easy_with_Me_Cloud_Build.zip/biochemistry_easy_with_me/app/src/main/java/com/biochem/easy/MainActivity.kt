package com.biochem.easy

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.functions.FirebaseFunctions
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

data class QuizQuestion(val id: String, val prompt: String, val options: List<String>, val explanation: String = "")

private val Navy = Color(0xFF102A43)
private val Teal = Color(0xFF0F9D9A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)
        setContent { MaterialTheme(colorScheme = lightColorScheme(primary = Navy, secondary = Teal)) { AppRoot() } }
    }
}

@Composable
fun AppRoot() {
    val auth = remember { FirebaseAuth.getInstance() }
    val db = remember { FirebaseFirestore.getInstance() }
    val functions = remember { FirebaseFunctions.getInstance() }
    var signedIn by remember { mutableStateOf(auth.currentUser != null) }
    var studentName by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    var questions by remember { mutableStateOf<List<QuizQuestion>>(emptyList()) }
    var current by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf<Int?>(null) }
    var score by remember { mutableIntStateOf(0) }
    var finished by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    suspend fun loadQuestions() {
        val snap = db.collection("questions").whereEqualTo("published", true).get().await()
        questions = snap.documents.mapNotNull { d ->
            val opts = d.get("options") as? List<*> ?: return@mapNotNull null
            QuizQuestion(d.id, d.getString("prompt") ?: return@mapNotNull null, opts.map { it.toString() }, d.getString("explanation") ?: "")
        }
        current = 0; selected = null; score = 0; finished = false
    }

    if (!signedIn) {
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
            Text("Biochemistry Easy with Me", style = MaterialTheme.typography.headlineMedium, color = Navy, fontWeight = FontWeight.Bold)
            Text("By Dr. Ahmed Al-Kisher · 2027 Edition", color = Teal)
            Spacer(Modifier.height(28.dp))
            OutlinedTextField(value = studentName, onValueChange = { studentName = it }, label = { Text("Student name") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(value = code, onValueChange = { code = it.uppercase() }, label = { Text("Subscription code") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(16.dp))
            Button(onClick = {
                if (studentName.isBlank() || code.isBlank()) { message = "Enter your name and subscription code."; return@Button }
                scope.launch {
                    busy = true; message = ""
                    try {
                        val result = functions.getHttpsCallable("redeemSubscriptionCode").call(mapOf("code" to code.trim(), "studentName" to studentName.trim())).await()
                        val token = (result.data as? Map<*, *>)?.get("token") as? String ?: error("No sign-in token returned")
                        auth.signInWithCustomToken(token).await()
                        signedIn = true
                        loadQuestions()
                    } catch (e: Exception) { message = e.localizedMessage ?: "Could not activate code." }
                    busy = false
                }
            }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "Please wait…" else "Activate & Sign in") }
            if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.error)
            Spacer(Modifier.height(12.dp))
            Text("Access is available only with a valid code issued by your instructor.", style = MaterialTheme.typography.bodySmall)
        }
    } else {
        LaunchedEffect(Unit) { runCatching { loadQuestions() }.onFailure { message = it.localizedMessage ?: "Unable to load questions" } }
        Column(Modifier.fillMaxSize().padding(20.dp)) {
            Text("Biochemistry Easy with Me", style = MaterialTheme.typography.titleLarge, color = Navy, fontWeight = FontWeight.Bold)
            Text("Question Bank & Exams", color = Teal)
            Spacer(Modifier.height(20.dp))
            if (finished) {
                Text("Exam completed", style = MaterialTheme.typography.headlineSmall, color = Navy)
                Text("Your score: $score / ${questions.size}", style = MaterialTheme.typography.headlineMedium)
                Button(onClick = { scope.launch { runCatching { loadQuestions() }.onFailure { message = it.message ?: "Error" } } }) { Text("Try again") }
            } else if (questions.isEmpty()) {
                Text(if (message.isBlank()) "No published questions yet. Please check again later." else message)
                Button(onClick = { scope.launch { runCatching { loadQuestions() }.onFailure { message = it.message ?: "Error" } } }) { Text("Refresh") }
            } else {
                Text("Question ${current + 1} of ${questions.size}", color = Teal, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(12.dp))
                Text(questions[current].prompt, style = MaterialTheme.typography.titleLarge, color = Navy)
                Spacer(Modifier.height(18.dp))
                questions[current].options.forEachIndexed { index, option ->
                    OutlinedButton(onClick = { selected = index }, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), colors = ButtonDefaults.outlinedButtonColors(containerColor = if (selected == index) Teal.copy(alpha = .12f) else Color.Transparent)) {
                        Text("${'A' + index}. $option", modifier = Modifier.fillMaxWidth())
                    }
                }
                Spacer(Modifier.height(18.dp))
                Button(enabled = selected != null, onClick = {
                    scope.launch {
                        val answer = selected!!
                        val grade = functions.getHttpsCallable("gradeAnswer").call(mapOf("questionId" to questions[current].id, "selectedIndex" to answer)).await()
                        val correct = (grade.data as? Map<*, *>)?.get("correct") as? Boolean ?: false
                        if (correct) score++
                        if (current == questions.lastIndex) finished = true else { current++; selected = null }
                    }
                }, modifier = Modifier.fillMaxWidth()) { Text(if (current == questions.lastIndex) "Finish exam" else "Next question") }
            }
            Spacer(Modifier.weight(1f))
            Text("Biochemistry Easy with Me · 2027", color = Teal, style = MaterialTheme.typography.labelSmall)
        }
    }
}
