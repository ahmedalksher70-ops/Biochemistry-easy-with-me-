import { onCall, HttpsError } from 'firebase-functions/v2/https';
import { initializeApp } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import { getFirestore, FieldValue } from 'firebase-admin/firestore';

initializeApp();
const db = getFirestore();

export const redeemSubscriptionCode = onCall(async (request) => {
  const code = String(request.data?.code ?? '').trim().toUpperCase();
  const studentName = String(request.data?.studentName ?? '').trim();
  if (!code || !studentName || studentName.length > 80) throw new HttpsError('invalid-argument', 'Enter a valid name and subscription code.');
  const codeRef = db.collection('subscriptionCodes').doc(code);
  const uid = await db.runTransaction(async (tx) => {
    const snap = await tx.get(codeRef);
    if (!snap.exists) throw new HttpsError('not-found', 'Invalid subscription code.');
    const data = snap.data()!;
    if (data.active !== true || data.used === true) throw new HttpsError('failed-precondition', 'This code is inactive or already used.');
    if (data.expiresAt && data.expiresAt.toDate() < new Date()) throw new HttpsError('deadline-exceeded', 'This subscription code has expired.');
    const studentRef = db.collection('students').doc();
    tx.update(codeRef, { used: true, usedBy: studentRef.id, usedAt: FieldValue.serverTimestamp() });
    tx.set(studentRef, { name: studentName, createdAt: FieldValue.serverTimestamp(), subscriptionCode: code, active: true });
    return studentRef.id;
  });
  const token = await getAuth().createCustomToken(uid, { student: true });
  return { token };
});

export const gradeAnswer = onCall(async (request) => {
  if (!request.auth) throw new HttpsError('unauthenticated', 'Sign in first.');
  const questionId = String(request.data?.questionId ?? '');
  const selectedIndex = Number(request.data?.selectedIndex);
  if (!questionId || !Number.isInteger(selectedIndex) || selectedIndex < 0 || selectedIndex > 7) throw new HttpsError('invalid-argument', 'Invalid answer.');
  const [question, key] = await Promise.all([
    db.collection('questions').doc(questionId).get(),
    db.collection('answerKeys').doc(questionId).get()
  ]);
  if (!question.exists || question.get('published') !== true || !key.exists) throw new HttpsError('not-found', 'Question not available.');
  const correctIndex = Number(key.get('correctIndex'));
  const correct = selectedIndex === correctIndex;
  await db.collection('attempts').add({ studentUid: request.auth.uid, questionId, selectedIndex, correct, createdAt: FieldValue.serverTimestamp() });
  return { correct, correctIndex, explanation: question.get('explanation') ?? '' };
});
