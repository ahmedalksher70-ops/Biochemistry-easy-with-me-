# Biochemistry Easy with Me — Android + Firebase

**الناشر:** By Dr. Ahmed Al-Kisher · Edition 2027  
**معرّف Android:** `com.biochem.easy`

## ما الذي أصبح موصولاً؟
- تسجيل الطالب بالبريد الإلكتروني وكلمة المرور عبر Firebase Authentication.
- التحقق من كود الاشتراك داخل Firestore.
- استهلاك الكود مرة واحدة (أو حتى `maxUses`) باستخدام معاملة Firestore ذرّية.
- إنشاء سجل الطالب في `students/{uid}` في المعاملة نفسها.
- الاحتفاظ بجلسة الطالب؛ عند فتح التطبيق لاحقاً يعاد فحص سجل الطالب.
- لا توجد Cloud Functions في هذا الإصدار، لذلك يمكن تجربة هذا المسار على خطة Firebase Spark المجانية.

## إعداد Firebase المطلوب قبل البناء
1. تأكد أن تطبيق Firebase Android مسجل بالمعرّف `com.biochem.easy`.
2. ضع ملف `google-services.json` داخل مجلد `app/` (النسخة المرفقة تخص مشروع Firebase `biochemistry-easy-with-me`).
3. في Firebase Console > Authentication > Sign-in method، فعّل **Email/Password**.
4. في Firestore، افتح تبويب **Rules** واستبدل القواعد بمحتوى الملف `firestore.rules` الموجود بجذر هذا المشروع، ثم اضغط **Publish**.
5. في `subscriptionCodes`، اجعل معرّف المستند هو الكود نفسه، وأضف الحقول:
   - `active` — Boolean — `true`
   - `maxUses` — Number — `1`
   - `usedCount` — Number — `0`
6. لا تضف `redeemedBy` يدوياً؛ التطبيق يضيفه عند نجاح الاسترداد.

## تجربة أول كود
- معرّف المستند: `BIO-2027-001`
- `active: true`
- `maxUses: 1`
- `usedCount: 0`
- أدخل في التطبيق بريداً إلكترونياً صالحاً وكلمة مرور من 6 أحرف على الأقل والكود أعلاه.
- بعد نجاح الدخول سيظهر سجل الطالب في `students`، وسيتغير `usedCount` إلى `1`.
- لا يمكن استخدام الكود مرة ثانية بعد استهلاكه.

## بناء APK عبر Codemagic
المشروع يستخدم Android Gradle Plugin 8.7.3 وJava 17. ملف `codemagic.yaml` في المستودع يفتح هذا المشروع المضغوط ويبني `assembleDebug`.

## حدود هذا الإصدار
- هذا ربط أولي فعلي للاشتراك، وليس لوحة تحكم مدرس مكتملة.
- إصدار الأكواد وإلغاؤها يتم حالياً من Firebase Console فقط.
- القواعد تسمح للطالب بقراءة مستند الكود الذي يعرف معرّفه، لكنها تمنع سرد جميع الأكواد وتمنع التعديل إلا بعملية الاسترداد المقيدة.
- حماية أقوى ضد التخمين وإدارة الإلغاء والتقارير تحتاج لاحقاً إلى App Check/خدمة خلفية موثوقة ومراجعة أمنية.
- ملف `google-services.json` إعداد عميل Android وليس مفتاح خدمة إدارية. لا تضع Service Account أو مفاتيح Admin داخل التطبيق.
