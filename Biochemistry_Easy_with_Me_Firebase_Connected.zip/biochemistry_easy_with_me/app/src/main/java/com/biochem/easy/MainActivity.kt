package com.biochem.easy

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

private val Navy = Color(0xFF102A43)
private val Teal = Color(0xFF16A6A1)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)
        setContent { BiochemistryApp() }
    }
}

@Composable
fun BiochemistryApp() {
    val auth = remember { FirebaseAuth.getInstance() }
    val db = remember { FirebaseFirestore.getInstance() }
    val scope = rememberCoroutineScope()

    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    var activated by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Checking your student access…") }
    var selected by remember { mutableIntStateOf(-1) }
    var submitted by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val user = auth.currentUser
        if (user != null) {
            try {
                val student = db.collection("students").document(user.uid).get().await()
                if (student.exists() && student.getBoolean("active") == true) {
                    activated = true
                    message = "Your student access is active."
                } else {
                    message = "Enter your email, password and teacher subscription code."
                }
            } catch (_: Exception) {
                message = "Connect to the internet, then try again."
            }
        } else {
            message = "Create your student account with your teacher's code."
        }
    }

    fun redeemAccess() {
        if (email.isBlank() || password.length < 6 || code.isBlank()) {
            message = "Enter a valid email, password (at least 6 characters), and subscription code."
            return
        }
        scope.launch {
            busy = true
            message = "Verifying your subscription code…"
            try {
                val cleanEmail = email.trim().lowercase()
                val credential = try {
                    auth.signInWithEmailAndPassword(cleanEmail, password).await()
                } catch (e: FirebaseAuthException) {
                    if (e.errorCode == "ERROR_USER_NOT_FOUND") {
                        auth.createUserWithEmailAndPassword(cleanEmail, password).await()
                    } else {
                        throw e
                    }
                }
                val uid = credential.user?.uid ?: auth.currentUser?.uid
                    ?: throw IllegalStateException("Student account could not be created.")
                val cleanCode = code.trim().uppercase()
                val codeRef = db.collection("subscriptionCodes").document(cleanCode)
                val studentRef = db.collection("students").document(uid)

                db.runTransaction { tx ->
                    val studentSnap = tx.get(studentRef)
                    if (studentSnap.exists()) {
                        if (studentSnap.getBoolean("active") == true) return@runTransaction true
                        throw IllegalStateException("This student account is disabled. Contact your teacher.")
                    }

                    val codeSnap = tx.get(codeRef)
                    if (!codeSnap.exists()) throw IllegalStateException("Subscription code not found.")
                    val active = codeSnap.getBoolean("active") == true
                    val maxUses = codeSnap.getLong("maxUses") ?: 1L
                    val usedCount = codeSnap.getLong("usedCount") ?: 0L
                    if (!active) throw IllegalStateException("This subscription code is inactive.")
                    if (usedCount >= maxUses) throw IllegalStateException("This subscription code has already been used.")

                    tx.update(
                        codeRef,
                        mapOf(
                            "usedCount" to usedCount + 1L,
                            "redeemedBy" to uid,
                            "redeemedAt" to FieldValue.serverTimestamp()
                        )
                    )
                    tx.set(
                        studentRef,
                        mapOf(
                            "active" to true,
                            "subscriptionCode" to cleanCode,
                            "email" to cleanEmail,
                            "createdAt" to FieldValue.serverTimestamp()
                        )
                    )
                    true
                }.await()

                activated = true
                message = "Access granted. Welcome to Biochemistry Easy with Me!"
            } catch (e: Exception) {
                val raw = e.message.orEmpty()
                message = when {
                    raw.contains("not found", ignoreCase = true) -> "Subscription code not found. Check it and try again."
                    raw.contains("already been used", ignoreCase = true) -> "This subscription code has already been used."
                    raw.contains("inactive", ignoreCase = true) -> "This subscription code is inactive. Contact your teacher."
                    raw.contains("PERMISSION_DENIED", ignoreCase = true) -> "Firebase permissions are not configured yet. Apply the Firestore rules supplied with this project."
                    raw.contains("network", ignoreCase = true) -> "Network error. Check your internet connection."
                    else -> "Could not activate access: ${raw.take(180)}"
                }
            } finally {
                busy = false
            }
        }
    }

    MaterialTheme(
        colorScheme = lightColorScheme(primary = Navy, secondary = Teal, background = Color(0xFFF5F8FA))
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Color(0xFFF5F8FA)) {
            Column(
                modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(24.dp))
                Text("BIOCHEMISTRY", color = Teal, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Text("Easy with Me", color = Navy, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                Text("By Dr. Ahmed Al-Kisher  •  Edition 2027", color = Color.DarkGray, fontSize = 12.sp)
                Spacer(Modifier.height(28.dp))
                Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(Modifier.padding(18.dp)) {
                        Text(if (activated) "Student Access Active" else "Student Access", color = Navy, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        if (!activated) {
                            Text("Create your student account and enter the subscription code provided by your teacher.")
                            OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Student email") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text("Password (6+ characters)") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                            OutlinedTextField(value = code, onValueChange = { code = it.uppercase() }, label = { Text("Subscription code") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                            Spacer(Modifier.height(10.dp))
                            Button(onClick = { redeemAccess() }, enabled = !busy, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Teal)) {
                                if (busy) CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp) else Text("Continue")
                            }
                        } else {
                            Text("Your account is connected to Firebase.")
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(message, color = Navy, fontSize = 13.sp)
                    }
                }
                Spacer(Modifier.height(18.dp))
                Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(Modifier.padding(18.dp)) {
                        Text("Sample Biochemistry Quiz", color = Navy, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(10.dp))
                        Text("Which molecule is the primary energy currency of the cell?", fontWeight = FontWeight.SemiBold)
                        listOf("ATP", "DNA", "Urea", "Cholesterol").forEachIndexed { index, answer ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                RadioButton(selected = selected == index, onClick = { selected = index; submitted = false })
                                Text(answer)
                            }
                        }
                        Button(onClick = { submitted = true }, enabled = selected >= 0, modifier = Modifier.fillMaxWidth()) { Text("Submit answer") }
                        if (submitted) {
                            Text(
                                if (selected == 0) "Correct! ATP transfers usable energy in cells." else "Not quite. The correct answer is ATP.",
                                color = if (selected == 0) Color(0xFF16804A) else Color(0xFFB3261E),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
                Spacer(Modifier.height(22.dp))
                Text("Firebase email/password + Firestore subscription validation", color = Color.Gray, fontSize = 11.sp)
            }
        }
    }
}
